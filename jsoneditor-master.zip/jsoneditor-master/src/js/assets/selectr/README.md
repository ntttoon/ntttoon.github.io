This is a copy of the Selectr project

https://github.com/Mobius1/Selectr

Reason is that the project is not maintained and has some issues
loading it via `require` in a webpack project.
